
fx_fgld_mc <- function(x, mu, L, psi, theta, B = 1e4){
  q <- ncol(theta)
  Y <- apply(theta, 2, \(x) qfgld_origin(runif(B), x))

  x_minus_mu <- t(t(x) - mu)

  apply(x_minus_mu, 1, \(x) dnorm(x - L %*% t(Y), sd = sqrt(psi), log = TRUE) |>
          colSums() |>
          exp() |>
          mean())
}

fx_given_u_fgld <- function(u, x, mu, L, theta, psi, logdet){
  q <- ncol(L)
  p <- length(mu)

  Qu <- array(dim = c(q, ncol(u)))
  for(j in 1:q){
    Qu[j, ] <- qfgld_origin(u[j, , drop = FALSE], theta[, j])
  }
  matrix(exp(-0.5 * (colSums((x - mu - L %*% Qu)^2 / psi) + p*log(2*pi) + logdet)),
         nrow = 1)
}

fx_fgld_cubature <- function(x, mu, L, psi, theta){
  x <- as.matrix(x)
  n <- nrow(x)
  q <- ncol(L)

  logdet <- sum(log(psi))

  out <- rep(NA, n)
  for(i in 1:n){
    out[i] <- cubature::hcubature(f = fx_given_u_fgld,
                                  lower = rep(0, q),
                                  upper = rep(1, q),
                                  x = x[i, ],
                                  mu = mu,
                                  L = L,
                                  theta = theta,
                                  psi = psi,
                                  logdet = logdet,
                                  vectorInterface = TRUE)$integral
  }

  return(out)
}


fx_given_u_gk <- function(u, x, mu, L, g, kappa, psi, logdet){
  q <- ncol(L)
  p <- length(mu)

  Qu <- array(dim = c(q, ncol(u)))
  for(j in 1:q){
    Qu[j, ] <- (1 + 0.8 * tanh(0.5 * g[j] * qnorm(u[j, , drop = FALSE]))) * qnorm(u[j, , drop = FALSE]) * (1 + qnorm(u[j, , drop = FALSE])^2)^kappa[j]
  }
  matrix(exp(-0.5 * (colSums((x - mu - L %*% Qu)^2 / psi) + p*log(2*pi) + logdet)),
         nrow = 1)
}



fx_gk_cubature <- function(x, mu, L, psi, g, kappa){
  x <- as.matrix(x)
  n <- nrow(x)
  q <- ncol(L)

  logdet <- sum(log(psi))

  out <- rep(NA, n)
  for(i in 1:n){
    out[i] <- cubature::hcubature(f = fx_given_u_gk,
                                  lower = rep(0, q),
                                  upper = rep(1, q),
                                  x = x[i, ],
                                  mu = mu,
                                  L = L,
                                  g = g,
                                  kappa = kappa,
                                  psi = psi,
                                  logdet = logdet,
                                  vectorInterface = TRUE)$integral
  }

  return(out)
}
