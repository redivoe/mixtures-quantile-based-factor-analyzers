
invQ <- function(x, theta, Q, eps = 1e-10, tol = 1e-6) {
  sapply(x, \(xi) tryCatch(stats::uniroot(function(u) Q(u, theta) - xi,
                                          interval = c(eps, 1 - eps), tol = tol)$root,
                           error = function(cond)
                             ifelse(xi > theta[1], 1 - eps, eps)
  )
  )
}

dQ <- function(x, theta, log = FALSE, Q, Qprime) {
  u <- invQ(x, theta, Q)
  if (isTRUE(log)) {
    return(- log(Qprime(u, theta)))
  } else{
    return(1 / Qprime(u, theta))
  }
}

rtheta_fgld <- function(p){
  beta <- rexp(p)
  alpha <- rnorm(p)
  delta <- runif(p)
  kappa <- rexp(p)
  rbind(alpha, beta, delta, kappa)
}

qfgld_origin <- function(u, theta){
  theta[1] + theta[2] * ((1 - theta[3]) * log(u) - theta[3] * log1p(-u) + theta[4] * u)
}

qfgld_origin_deriv <- function(u, theta) {
  ifelse(u >= 1 - 1e-10 | u <= 1e-10,
         1e10,
         theta[2] * ((1 - theta[3]) / (u) + theta[3] / (1 - u) + theta[4]))
}

pfgld <- function(q, theta, eps = 1e-10, tol = 1e-6){
  invQ(q, theta, Q = qfgld_origin, eps = eps, tol = tol)
}

dfgld <- function(x, theta, log = FALSE){
  dQ(x, theta, log = log, Q = qfgld_origin, Qprime = qfgld_origin_deriv)
}


var_fgld <- function(alpha, beta, delta, kappa){
  beta ^ 2 * (1 + (base::pi ^ 2 / 3 - 4) * delta * (1 - delta) + kappa / 2 * (1 + kappa / 6))
}

mean_fgld <- function(alpha, beta, delta, kappa){
  alpha + beta * (2 * delta - 1 + kappa / 2)
}

h1 <- function(delta, kappa){
  1 + (base::pi ^ 2 / 3 - 4) * delta * (1 - delta) + kappa / 2 * (1 + kappa / 6)
}

get_beta_std <- function(delta, kappa){
  sqrt(1 / h1(delta, kappa))
}

get_alpha_std <- function(beta, delta, kappa){
  - beta * (2 * delta - 1 + kappa / 2)
}

rtheta_std <- function(p){
  delta <- runif(p)
  kappa <- rlnorm(p, meanlog = 0, sdlog = 1)
  beta <- get_beta_std(delta, kappa)
  alpha <- get_alpha_std(beta, delta, kappa)
  rbind(alpha, beta, delta, kappa)
}

complete_theta_std <- function(delta, kappa){
  beta <- get_beta_std(delta, kappa)
  alpha <- get_alpha_std(beta, delta, kappa)
  return(c(alpha, beta, delta, kappa))
}

theta_norm2origin <- function(theta_norm){
  c(theta_norm[1], exp(theta_norm[2]), pnorm(theta_norm[3]), exp(theta_norm[4]))
}

theta_origin2norm <- function(theta){
  eps <- 1e-3
  if(theta[2] == 0){
    theta[2] <- theta[2] + eps
  }
  if(theta[3] == 0){
    theta[3] <- theta[3] + eps
  }
  if(theta[3] == 1){
    theta[3] <- theta[3] - eps
  }
  if(theta[4] == 0){
    theta[4] <- theta[4] + eps
  }
  c(theta[1], log(theta[2]), qnorm(theta[3]), log(theta[4]))
}

log_likelihood_fgld_unbounded_u <- function(u, theta, eps){
  if(any(u == eps) | any(u == (1-eps))){
    return(-1e100)
  }else{
    n <- length(u)
    -n * theta[2] - sum(log(1 + 2 * pnorm(theta[3]) * u - pnorm(theta[3]) - u + exp(theta[4] + log1p(-u) + log(u)))) + sum(log(u)) + sum(log1p(-u))
  }
}

log_prior_fgld_std <- function(theta){
  dnorm(theta[1], 0, 1, log = TRUE) +
    dnorm(theta[2], 0, 1, log = TRUE)
}

log_post_u <- function(y, A, b){
  - 0.5 * colSums(y * (A %*% y)) + sum(y * b)
}


theta_minus <- function(theta){
  c(-theta[1] - theta[2]*theta[4], theta[2], 1 - theta[3], theta[4])
}
