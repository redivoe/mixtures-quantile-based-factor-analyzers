
r_mfa_params <- function(p,
                         q,
                         K,
                         mu0 = 0,
                         sigma0 = 1,
                         a0_psi = 10,
                         b0_psi = 0.5,
                         a0_omega = 0.5,
                         b0_omega = 0.5,
                         alpha0_p = 10,
                         common_psi = FALSE){
  
  mu0 <- rep(mu0, p)
  Sigma0 <- diag(rep(sigma0, p))

  L <- array(dim = c(p, q, K))
  mu <- array(dim = c(p, K))
  for(k in 1:K){
    L[, , k] <-  rnorm(n = p * q)
    L[, , k][upper.tri(L[, , k])] <- 0
    mu[, k] <- mvnfast::rmvn(n = 1, mu = mu0, sigma = Sigma0)
  }
  
  prop <- c(MCMCpack::rdirichlet(n = 1, rep(alpha0_p, K)))

  if(common_psi){
    psi <- MCMCpack::rinvgamma(n = p, shape = a0_psi, scale = b0_psi)
  }else{
    psi <- array(MCMCpack::rinvgamma(n = p * K, shape = a0_psi, scale = b0_psi),
                 dim = c(p, K))
  }

  omega <- MCMCpack::rinvgamma(n = q, shape = a0_omega, scale = b0_omega)
  
  return(list("prop" = prop,
              "mu" = mu,
              "L" = L,
              "psi" = psi,
              "omega" = omega,
              "common_psi" = common_psi))
}


r_mfa_data <- function(n, p, q, K, with_Y = FALSE, params, ...){
  if(missing(params)){
    params <- r_mfa_params(p, q, K, ...)
  }

  z <- sample(x = K, size = n, replace = TRUE, prob = params$prop)
  X <- array(dim = c(n, p))

  Y <- array(rnorm(n * q), dim = c(n, q))
  log_lik <- numeric(n)

  if(with_Y){

    if(params$common_psi){
      for(i in 1:n){
        X[i, ] <- rnorm(n = p,
                        mean = params$L[, , z[i]] %*% Y[i, ] + params$mu[, z[i]],
                        sd = sqrt(params$psi))
        log_lik[i] <- sum(dnorm(x = X[i, ],
                                mean = params$L[, , z[i]] %*% Y[i, ] + params$mu[, z[i]],
                                sd = sqrt(params$psi),
                                log = TRUE))
      }
    }else{
      for(i in 1:n){
        X[i, ] <- rnorm(n = p,
                        mean = params$L[, , z[i]] %*% Y[i, ] + params$mu[, z[i]],
                        sd = sqrt(params$psi[, z[i]]))
        log_lik[i] <- sum(dnorm(x = X[i, ],
                                mean = params$L[, , z[i]] %*% Y[i, ] + params$mu[, z[i]],
                                sd = sqrt(params$psi[, z[i]]),
                                log = TRUE))
      }
    }

    params$Y <- Y
    params$log_lik <- log_lik

  }else{

    if(params$common_psi){
      for(i in 1:n){
        X[i, ] <- mvnfast::rmvn(n = 1,
                                mu = params$mu[, z[i]],
                                sigma = tcrossprod(params$L[, , z[i]]) + diag(params$psi))
      }
    }else{
      for(i in 1:n){
        X[i, ] <- mvnfast::rmvn(n = 1,
                                mu = params$mu[, z[i]],
                                sigma = tcrossprod(params$L[, , z[i]]) + diag(params$psi[, z[i]]))
      }
    }
  }

  params$z <- z

  return(list("X" = X,
              "params" = params))

}
