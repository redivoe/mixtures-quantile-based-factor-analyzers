
mfa_psi_common <- function(X,
                           K,
                           q,
                           R = 10000,
                           burn_in = 0,
                           params_init = NULL,
                           out_mcmc = TRUE,
                           z_update_distr = c("marginal", "conditional"),
                           quiet = FALSE) {

  n <- nrow(X)
  p <- ncol(X)

  # distribution for updating z
  z_update_distr <- match.arg(z_update_distr)

  # hyperparameter values
  a0_psi <- 0.5
  b0_psi <- 0.5
  a0_omega <- 0.5
  b0_omega <- 0.5
  alpha_p <- rep(1, K)
  mu0 <- rep(0, p)
  Sigma0 <- diag(rep(1, p))

  # number of free parameters for each row of Lambda
  pl <- c(1:q, rep(q, p - q))

  # initial values
  if(missing(params_init)){
    psi <- MCMCpack::rinvgamma(n = p, shape = a0_psi, scale = b0_psi)
    omega <- MCMCpack::rinvgamma(n = q, shape = a0_omega, scale = b0_omega)
    L <- array(rnorm(p * q * K, sd = 2), dim = c(p, q, K))
    for(k in 1:K){
      L[, , k][upper.tri(L[, , k])] <- 0
    }
    mu <- array(rnorm(p * K, sd = 2), dim = c(p, K))
    prop <- c(MCMCpack::rdirichlet(n = 1,
                                 alpha = rep((2 * p + p * q - q * (q - 1) / 2)/2, K)))
    z <- sample(K, size = n, prob = prop, replace = TRUE)
    nk <- sapply(1:K, \(k) sum(z == k))
  }else{
    psi <- params_init$psi
    L <- params_init$L
    mu <- params_init$mu
    prop <- c(params_init$prop)
    Y <- params_init$Y
    z <- params_init$z
    nk <- sapply(1:K, \(k) sum(z == k))
    omega <- rep(1, q)
  }

  Y <- array(dim = c(n, q)) # empty

  if(out_mcmc){
    out <- list(
      L = array(dim = c(R, p * q * K)),
      psi = array(dim = c(R, p)),
      omega = array(dim = c(R, q)),
      mu = array(dim = c(R, p * K)),
      prop = array(dim = c(R, K)),
      z = array(dim = c(R, n)),
      Y = array(dim = c(R, n * q))
    )

  }else{
    out <- list(
      L = array(dim = c(p, q, K, R)),
      psi = array(dim = c(p, R)),
      omega = array(dim = c(q, R)),
      mu = array(dim = c(p, K, R)),
      prop = array(dim = c(K, R)),
      z = array(dim = c(n, R))
    )
  }

  if(!quiet){
    prog_bar <- progress::progress_bar$new(total = R + burn_in,
                                           format = "[:bar] :percent eta: :eta")
  }


  for (r in 1:(burn_in + R)) {
    b_psi <- rep(0, p)
    b_omega <- rep(0, q)

    for(k in 1:K){
      idx_k <- which(z == k)

      if(length(idx_k) == 0){
        warning(paste0("Component ", k, " is empty.\t"))

        mu[, k] <- mvnfast::rmvn(n = 1, mu = mu0, sigma = Sigma0)
        for(l in 1:p){
          L[l, 1:pl[l], k] <- mvnfast::rmvn(n = 1, mu = rep(0, pl[l]), sigma = diag1(omega[1:pl[l]]))
        }
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)

      }else{

        # Y
        Syk <- solve(diag(rep(1, q)) + t(L[, , k]) %*% diag(1 / psi) %*% L[, , k])
        myk <- sweep(X[idx_k, , drop = FALSE], 2, mu[, k]) %*% diag(1 / psi) %*% L[, , k] %*% Syk
        Y[idx_k, ] <- myk + mvnfast::rmvn(n = nk[k], mu = rep(0, q), sigma = Syk)

        # mu
        Smuk <- solve(nk[k] * diag(1 / psi) + solve(Sigma0))
        mu[, k] <- mvnfast::rmvn(n = 1,
                                 mu = Smuk %*% (diag(1/psi) %*% colSums(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k])) + solve(Sigma0) %*% mu0),
                                 sigma = Smuk)

        # Lambda
        for(l in 1:p){
          Yl <- Y[idx_k, 1:pl[l], drop = FALSE]
          Slk <- solve(diag1(1 / omega[1:pl[l]]) + crossprod(Yl) / psi[l])
          mlk <- Slk %*% t(Yl) %*% (X[idx_k, l] - mu[l, k]) / psi[l]
          L[l, 1:pl[l], k] <- mvnfast::rmvn(n = 1, mu = mlk, sigma = Slk)
        }

        b_psi <- b_psi + colSums(sweep(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k]), 2, mu[, k]) ^ 2)
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)
        }
    }

    for (l in 1:p) {
      psi[l] <- MCMCpack::rinvgamma(n = 1,
                                    shape = a0_psi + n / 2,
                                    scale = b0_psi + b_psi[l] / 2)
    }
    for(j in 1:q){
      omega[j] <- MCMCpack::rinvgamma(n = 1,
                                      shape = a0_omega + K * p / 2,
                                      scale = b0_omega + b_omega[j] / 2)
    }

    if(K > 1){
      z <- switch(z_update_distr,
                  "marginal" = update_z_marginal(X, prop, mu, L, psi),
                  "conditional" = update_z_conditional(X, prop, mu, L, psi, Y))
      nk <- sapply(1:K, \(k) sum(z == k))
      prop <- c(MCMCpack::rdirichlet(n = 1, alpha = alpha_p + nk))
    }

    if(r > burn_in){

      if(out_mcmc){
        out$L[r - burn_in, ] <- c(L)
        out$psi[r - burn_in, ] <- psi
        out$omega[r - burn_in, ] <- omega
        out$mu[r - burn_in, ] <- c(mu)
        out$prop[r - burn_in, ] <- prop
        out$z[r - burn_in, ] <- z
        out$Y[r - burn_in, ] <- c(Y)
      }else{
        out$L[, , , r - burn_in] <- L
        out$psi[, r - burn_in] <- psi
        out$omega[, r - burn_in] <- omega
        out$mu[, , r - burn_in] <- mu
        out$prop[, r - burn_in] <- prop
        out$z[, r - burn_in] <- z
      }
    }

    if (!quiet) {
      prog_bar$tick()
    }

  }

  z_map <- numeric(n)
  for(i in 1:n){
    z_map[i] <- which.max(sapply(1:K, \(k) sum(out$z[,i] == k)))
  }
  out$z_map <- z_map

  return(out)

}


