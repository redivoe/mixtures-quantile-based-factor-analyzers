diag1 <- function(x){
  if(length(x) == 1){
    x
  }else{
    diag(x)
  }
}

update_z_conditional <- function(X, prop, mu, L, psi, Y, psi_common = TRUE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  log_lik <- array(dim = c(n, K))

  if(psi_common){
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- sum(dnorm(x = X[i, ],
                                    mean = mu[, k] + L[, , k] %*% t(Y[i, , drop = FALSE]),
                                    sd = sqrt(psi),
                                    log = TRUE))
      }
    }
  }else{
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- sum(dnorm(x = X[i, ],
                                    mean = mu[, k] + L[, , k] %*% t(Y[i, , drop = FALSE]),
                                    sd = sqrt(psi[, k]),
                                    log = TRUE))
      }
    }
  }

  log_post <- t(t(log_lik) + log(prop))

  return(get_z_and_point_lik(log_post))
}

update_z_marginal <- function(X, prop, mu, L, psi, psi_common = TRUE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  Sigma <- array(dim = c(p, p, K))

  if(psi_common){
    for (k in 1:K) {
      Sigma[, , k] <- tcrossprod(L[, , k]) + diag(psi)
    }
  }else{
    for (k in 1:K) {
      Sigma[, , k] <- tcrossprod(L[, , k]) + diag(psi[, k])
    }
  }

  log_post <- array(dim = c(n, K))
  for(k in 1:K){
    log_post[, k] <- log(prop[k]) +
      mvnfast::dmvn(X = X, mu = mu[, k], sigma = Sigma[, , k], log = TRUE)
  }

  return(get_z_and_point_lik(log_post))
}


update_z_marginal_mc <- function(X, prop, mu, L, psi, theta, psi_common = TRUE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  q <- dim(L)[2]
  B <- 2e3

  Y <- array(dim = c(B, q, K))
  for(k in 1:K){
    for(j in 1:q){
      Y[, j, k] <- ifa2::qfgld_origin(u = runif(B), theta = theta[, j, k])
    }
  }

  log_lik <- array(dim = c(n, K))

  if(psi_common){
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- mean(dnorm(x = X[i, ],
                                    mean = mu[, k] + L[, , k] %*% t(Y[, , k]),
                                    sd = sqrt(psi),
                                    log = TRUE))
      }
    }
  }else{
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- mean(dnorm(x = X[i, ],
                                    mean = mu[, k] + L[, , k] %*% t(Y[, , k]),
                                    sd = sqrt(psi[, k]),
                                    log = TRUE))
      }
    }
  }

  log_post <- t(t(log_lik) + log(prop))


  return(get_z_and_point_lik(log_post))
}



get_z_and_point_lik <- function(log_post){
  K <- ncol(log_post)
  post <- t(apply(log_post, 1, \(x) exp(x - max(x))))
  z <- apply(post, 1, \(post_probs_i) sample(x = K, size = 1, prob = post_probs_i))

  return(list("z" = z,
              "point_lik" = rowSums(post)))
}

waic_point_lik <- function(point_lik){
  R <- nrow(point_lik)
  n <- ncol(point_lik)

  llpd <- sum(log(colMeans(point_lik)))
  p_waic2 <- sum(apply(log(point_lik), 2, var))

  waic <- -2 * llpd + 2 * p_waic2
  return(waic)
}

