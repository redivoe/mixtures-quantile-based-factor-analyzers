
mfa_random_init <- function(n,
                            p,
                            q,
                            K,
                            mu0 = 0,
                            sigma0 = 1,
                            a0_psi = 0.5,
                            b0_psi = 0.5,
                            a0_omega = 0.5,
                            b0_omega = 0.5,
                            alpha0_p = 10,
                            common_psi = FALSE) {
  
  params_init <- r_mfa_params(p, q, K, mu0, sigma0, a0_psi, b0_psi, a0_omega, b0_omega, alpha0_p, common_psi)
  params_init$z <- sample(K, size = n, prob = params_init$prop, replace = TRUE)

  return(params_init)
}


mifa_random_init <- function(n, p, q, K){
  a0_psi <- 5
  b0_psi <- 0.5
  a0_omega <- 0.5
  b0_omega <- 0.5
  alpha0_p <- rep(p * q * K, K)
  mu0 <- rep(0, p)
  Sigma0 <- diag(rep(1, p))
  
  psi <- array(MCMCpack::rinvgamma(n = p * K, shape = a0_psi, scale = b0_psi),
               dim = c(p, K))
  omega <- MCMCpack::rinvgamma(n = q, shape = a0_omega, scale = b0_omega)
  L <- array(rnorm(p * q * K), dim = c(p, q, K))
  mu <- t(mvnfast::rmvn(n = K, mu = mu0, sigma = Sigma0))
  prop <- c(MCMCpack::rdirichlet(n = 1, alpha = alpha0_p))
  z <- sample(K, size = n, prob = prop, replace = TRUE)
  nk <- sapply(1:K, \(k) sum(z == k))
  
  U <- matrix(runif(n * q), n, q)
  theta <- array(rtheta_std(q * K), dim = c(4, q, K))
  Y <- array(dim = c(n, q))
  for(k in 1:K){
    idx_k <- which(z == k)
    if(length(idx_k) > 0){
      Y[idx_k, ] <- sapply(1:q, \(j) qfgld_origin(U[idx_k, j], theta[, j, k]))
    }
  }
  
  return(list("psi" = psi,
              "omega" = omega,
              "L" = L,
              "mu" = mu,
              "prop" = prop,
              "z" = z,
              "U" = U,
              "theta" = theta,
              "Y" = Y))
}






mfa_kmeans_init <- function(X, K, q, psi_common = FALSE){
  n <- nrow(X)
  p <- ncol(X)

  out_kmeans <- kmeans(x = X, centers = K, nstart = 20)
  z <- out_kmeans$cluster
  nk <- sapply(1:K, \(k) sum(z == k))
  prop <- nk/n
  mu <- t(out_kmeans$centers)
  L <- array(dim = c(p, q, K))

  if(psi_common){
    psi <- rep(0, p)
  }else{
    psi <- array(dim = c(p, K))
  }

  for(k in 1:K){
    fa_out <- factanal(X[which(z == k),], q, control = list(nstart = 10, lower = 0.01))
    L[, , k] <- unclass(fa_out$loadings)
    if(psi_common){
      psi <- psi + fa_out$uniquenesses
    }else{
      psi[, k] <- fa_out$uniquenesses
    }
  }

  return(list(
    "z" = z,
    "prop" = prop,
    "mu" = mu,
    "L" = L,
    "psi" = psi
  ))
}


mifa_fgld_kmeans_init <- function(X, K, q, psi_common = FALSE){
  n <- nrow(X)
  p <- ncol(X)

  out_kmeans <- kmeans(x = X, centers = K, nstart = 20)
  z <- out_kmeans$cluster
  nk <- sapply(1:K, \(k) sum(z == k))
  prop <- nk/n
  mu <- t(out_kmeans$centers)
  L <- array(dim = c(p, q, K))

  if(psi_common){
    psi <- rep(0, p)
  }else{
    psi <- array(dim = c(p, K))
  }

  for(k in 1:K){
    fa_out <- factanal(X[which(z == k),], q)
    L[, , k] <- unclass(fa_out$loadings)
    if(psi_common){
      psi <- psi + fa_out$uniquenesses
    }else{
      psi[, k] <- fa_out$uniquenesses
    }
  }

  theta <- array(rtheta_std(q * K), dim = c(4, q, K))

  return(list(
    "z" = z,
    "prop" = prop,
    "mu" = mu,
    "L" = L,
    "psi" = psi,
    "theta" = theta
  ))
}

