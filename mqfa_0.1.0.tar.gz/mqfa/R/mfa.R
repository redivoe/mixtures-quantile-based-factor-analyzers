
mfa <- function(X,
                K,
                q,
                R = 2000,
                burn_in = 2000,
                params_init = NULL,
                out_mcmc = TRUE,
                z_update = c("marginal", "conditional"),
                quiet = FALSE){

  n <- nrow(X)
  p <- ncol(X)

  # distribution for updating z
  z_update <- match.arg(z_update)

  update_z_fun <- switch(z_update,
                         "marginal" = update_z_marginal_mfa,
                         "conditional" = update_z_conditional_mfa)
  update_z_fun_args <- switch(z_update,
                              "marginal" = c("X", "prop", "mu", "L", "psi"),
                              "conditional" = c("X", "prop", "mu", "L", "psi", "Y"))

  # hyperparameter values
  a0_psi <- 0.5
  b0_psi <- 0.5
  a0_omega <- 0.5
  b0_omega <- 0.5
  alpha0_p <- rep(10, K)
  mu0 <- rep(0, p)
  sigma0 <- rep(1, p)
  Sigma0 <- diag(sigma0)
  Sigma0_inv <- diag(1/sigma0)

  # number of free parameters for each row of Lambda
  pl <- c(1:q, rep(q, p - q))

  # initial values
  if(missing(params_init)){
   params_init <- mfa_random_init(n,
                                  p,
                                  q,
                                  K,
                                  mu0 = 0,
                                  sigma0 = 1,
                                  a0_psi = 0.5,
                                  b0_psi = 0.5,
                                  a0_omega = 0.5,
                                  b0_omega = 0.5,
                                  alpha0_p = 10)
  }

  prop <- c(params_init$prop)
  mu <- params_init$mu
  L <- params_init$L
  psi <- params_init$psi
  omega <- params_init$omega
  z <- params_init$z

  nk <- sapply(1:K, \(k) sum(z == k))

  Y <- array(dim = c(n, q)) # empty
  point_lik <- array(dim = c(R, n))

  if(out_mcmc){
    out <- list(
      L = array(dim = c(R, p * q * K)),
      psi = array(dim = c(R, p * K)),
      omega = array(dim = c(R, q)),
      mu = array(dim = c(R, p * K)),
      prop = array(dim = c(R, K)),
      z = array(dim = c(R, n)),
      Y = array(dim = c(R, n * q))
    )

  }else{
    out <- list(
      L = array(dim = c(p, q, K, R)),
      psi = array(dim = c(p, K, R)),
      omega = array(dim = c(q, R)),
      mu = array(dim = c(p, K, R)),
      prop = array(dim = c(K, R)),
      z = array(dim = c(n, R))
    )
  }

  if(!quiet){
    prog_bar <- progress::progress_bar$new(total = R + burn_in,
                                           format = "[:bar] :percent eta: :eta")
  }


  for (r in 1:(burn_in + R)) {
    b_omega <- rep(0, q)

    for(k in 1:K){
      idx_k <- which(z == k)

      if(length(idx_k) == 0){
        # warning(paste0("Component ", k, " is empty.\t"))

        mu[, k] <- mvnfast::rmvn(n = 1, mu = mu0, sigma = Sigma0)
        for(l in 1:p){
          L[l, 1:pl[l], k] <- mvnfast::rmvn(n = 1, mu = rep(0, pl[l]), sigma = diag1(omega[1:pl[l]]))
          psi[l, k] <- MCMCpack::rinvgamma(n = 1,
                                           shape = a0_psi,
                                           scale = b0_psi)
        }
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)

      }else{

        # Y
        Syk <- solve(diag(rep(1, q)) + t(L[, , k]) %*% diag(1 / psi[, k]) %*% L[, , k])
        myk <- sweep(X[idx_k, , drop = FALSE], 2, mu[, k]) %*% diag(1 / psi[, k]) %*% L[, , k] %*% Syk
        Y[idx_k, ] <- myk + mvnfast::rmvn(n = nk[k], mu = rep(0, q), sigma = Syk)

        # mu
        # Smuk <- solve(nk[k] * diag(1 / psi[, k]) + solve(Sigma0))
        Smuk <- diag(1 / (nk[k] / psi[, k] + 1/sigma0))
        mu[, k] <- mvnfast::rmvn(n = 1,
                                 mu = Smuk %*% (diag(1/psi[, k]) %*% colSums(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k])) + solve(Sigma0) %*% mu0),
                                 sigma = Smuk)

        # Lambda
        for(l in 1:p){
          Yl <- Y[idx_k, 1:pl[l], drop = FALSE]
          Slk <- solve(diag1(1 / omega[1:pl[l]]) + crossprod(Yl) / psi[l, k])
          mlk <- Slk %*% t(Yl) %*% (X[idx_k, l] - mu[l, k]) / psi[l, k]
          L[l, 1:pl[l], k] <- mvnfast::rmvn(n = 1, mu = mlk, sigma = Slk)
        }

        b_psi <- colSums(sweep(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k]), 2, mu[, k]) ^ 2)
        for (l in 1:p) {
          psi[l, k] <- MCMCpack::rinvgamma(n = 1,
                                           shape = a0_psi + nk[k] / 2,
                                           scale = b0_psi + b_psi[l] / 2)
        }

        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)
      }
    }

    for(j in 1:q){
      omega[j] <- MCMCpack::rinvgamma(n = 1,
                                      shape = a0_omega + K * p / 2,
                                      scale = b0_omega + b_omega[j] / 2)
    }

    if(K > 1){
      out_z_update <- do.call(what = update_z_fun, args = mget(update_z_fun_args))
      z <- out_z_update$z
      nk <- sapply(1:K, \(k) sum(z == k))
      prop <- c(MCMCpack::rdirichlet(n = 1, alpha = alpha0_p + nk))
    }

    if(r > burn_in){
      if(K > 1){
        point_lik[r - burn_in, ] <- out_z_update$point_lik
      }

      if(out_mcmc){
        out$L[r - burn_in, ] <- c(L)
        out$psi[r - burn_in, ] <- psi
        out$omega[r - burn_in, ] <- omega
        out$mu[r - burn_in, ] <- c(mu)
        out$prop[r - burn_in, ] <- prop
        out$z[r - burn_in, ] <- z
        out$Y[r - burn_in, ] <- c(Y)
      }else{
        out$L[, , , r - burn_in] <- L
        out$psi[, r - burn_in] <- psi
        out$omega[, r - burn_in] <- omega
        out$mu[, , r - burn_in] <- mu
        out$prop[, r - burn_in] <- prop
        out$z[, r - burn_in] <- z
      }
    }

    if (!quiet) {
      prog_bar$tick()
    }

  }

  z_map <- numeric(n)
  for(i in 1:n){
    z_map[i] <- which.max(sapply(1:K, \(k) sum(out$z[,i] == k)))
  }
  out$z_map <- z_map
  out$waic <- waic_point_lik(point_lik)
  out$wbic <- wbic_point_lik(point_lik)

  return(out)

}


