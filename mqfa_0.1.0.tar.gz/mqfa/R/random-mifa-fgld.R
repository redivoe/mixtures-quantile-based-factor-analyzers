
r_mifa_fgld_params <- function(p, q, K,
                               common_theta = FALSE,
                               common_psi = FALSE){

  out <- r_mfa_params(p, q, K, common_psi)

  if(common_theta){
    theta <- rtheta_std(q)
  }else{
    theta <- array(rtheta_std(q * K), dim = c(4, q, K))
  }

  out$theta <- theta
  out$common_theta <- common_theta

  return(out)
}


r_mifa_fgld_data <- function(n, p, q, K, params,
                             common_theta = FALSE,
                             common_psi = FALSE){
  if(missing(params)){
    params <- r_mifa_fgld_params(p, q, K, common_theta, common_psi)
  }

  z <- sample(x = K, n, replace = TRUE, prob = params$prop)
  X <- array(dim = c(n, p))

  U <- matrix(runif(n * q), n, q)

  if(params$common_theta){
    Y <- sapply(1:q, \(j) qfgld_origin(U[, j], params$theta[, j]))
  }else{
    Y <- array(dim = c(n, q))
    for(k in 1:K){
      idx_k <- which(z == k)
      Y[idx_k, ] <- sapply(1:q, \(j) qfgld_origin(U[idx_k, j], params$theta[, j, k]))
    }
  }

  if(params$common_psi){
    for(i in 1:n){
      X[i, ] <- rnorm(n = p,
                      mean = params$L[, , z[i], drop = FALSE] %*% Y[i, , drop = FALSE] + params$mu[, z[i]],
                      sd = sqrt(params$psi))
    }
  }else{
    for(i in 1:n){
      X[i, ] <- rnorm(n = p,
                      mean = params$L[, , z[i], drop = FALSE] %*% Y[i, , drop = FALSE] + params$mu[, z[i]],
                      sd = sqrt(params$psi[, z[i]]))
    }
  }
  params$Y <- Y
  params$z <- z

  return(list("X" = X,
              "params" = params))

}
