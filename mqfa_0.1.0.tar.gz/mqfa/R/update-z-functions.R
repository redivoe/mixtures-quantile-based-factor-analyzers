# diag1 <- function(x){
#   if(length(x) == 1){
#     x
#   }else{
#     diag(x)
#   }
# }

#################################################################
##                             MFA                             ##
#################################################################

##---------------
##  Conditional
##---------------

update_z_conditional_mfa <- function(X, prop, mu, L, psi, Y, psi_common = FALSE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  log_lik <- array(dim = c(n, K))

  if(psi_common){
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- sum(dnorm(x = X[i, ],
                                    mean = mu[, k] + L[, , k] %*% t(Y[i, , drop = FALSE]),
                                    sd = sqrt(psi),
                                    log = TRUE))
      }
    }
  }else{
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- sum(dnorm(x = X[i, ],
                                    mean = mu[, k] + L[, , k] %*% t(Y[i, , drop = FALSE]),
                                    sd = sqrt(psi[, k]),
                                    log = TRUE))
      }
    }
  }

  log_post <- t(t(log_lik) + log(prop))

  return(get_z_and_point_lik(log_post))
}


##------------
##  Marginal
##------------

update_z_marginal_mfa <- function(X, prop, mu, L, psi, psi_common = FALSE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  Sigma <- array(dim = c(p, p, K))

  if(psi_common){
    for (k in 1:K) {
      Sigma[, , k] <- tcrossprod(L[, , k]) + diag(psi)
    }
  }else{
    for (k in 1:K) {
      Sigma[, , k] <- tcrossprod(L[, , k]) + diag(psi[, k])
    }
  }

  log_post <- array(dim = c(n, K))
  for(k in 1:K){
    log_post[, k] <- log(prop[k]) +
      mvnfast::dmvn(X = X, mu = mu[, k], sigma = Sigma[, , k], log = TRUE)
  }

  return(get_z_and_point_lik(log_post))
}










##################################################################
##                           MFA fgld                           ##
##################################################################

##---------------
##  Conditional
##---------------

update_z_conditional_fgld <- function(X, prop, mu, L, psi, Y, theta, psi_common = FALSE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  log_lik <- array(dim = c(n, K))

  if(psi_common){
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- sum(dnorm(x = X[i, ],
                                   mean = mu[, k] + L[, , k] %*% t(Y[i, , drop = FALSE]),
                                   sd = sqrt(psi),
                                   log = TRUE))
      }
    }
  }else{
    for(k in 1:K){
      for(i in 1:n){
        log_lik[i, k] <- sum(dnorm(x = X[i, ],
                                   mean = mu[, k] + L[, , k] %*% t(Y[i, , drop = FALSE]),
                                   sd = sqrt(psi[, k]),
                                   log = TRUE))
      }
    }
  }

  for(k in 1:K){
    for(j in 1:q){
      log_lik[, k] <- log_lik[, k] + dfgld(x = Y[, j], theta = theta[, j, k], log = TRUE)
    }
  }

  log_post <- t(t(log_lik) + log(prop))

  return(get_z_and_point_lik(log_post))
}



##------------
##  Marginal
##------------

update_z_marginal_fgld <- function(X, prop, mu, L, psi, theta, monte_carlo = FALSE, B = 1e3, psi_common = FALSE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  q <- dim(L)[2]

  log_lik <- array(dim = c(n, K))

  if(monte_carlo){

    Y <- array(dim = c(B, q, K))
    for(k in 1:K){
      for(j in 1:q){
        Y[, j, k] <- qfgld_origin(u = runif(B), theta = theta[, j, k])
      }
    }


    if(psi_common){
      for(k in 1:K){
        for(i in 1:n){
          log_lik[i, k] <- matrixStats::logSumExp(colSums(dnorm(x = X[i, ],
                                                                mean = mu[, k] + L[, , k] %*% t(Y[, , k]),
                                                                sd = sqrt(psi),
                                                                log = TRUE)))
        }
      }
    }else{
      for(k in 1:K){
        for(i in 1:n){
          log_lik[i, k] <- matrixStats::logSumExp(colSums(dnorm(x = X[i, ],
                                                                mean = mu[, k] + L[, , k] %*% t(Y[, , k]),
                                                                sd = sqrt(psi[, k]),
                                                                log = TRUE)))
        }
      }
    }

    log_lik <- log_lik - log(B)

  }else{

    for(k in 1:K){
      fx <- fx_fgld_cubature(x = X,
                             mu = mu[, k],
                             L = matrix(L[, , k], nrow = p, ncol = q),
                             psi = psi[, k],
                             theta = matrix(theta[, , k], nrow = 4, ncol = q))
      log_lik[, k] <- log(ifelse((fx <= 0) | (is.nan(fx)), yes = .Machine$double.eps, no = fx))
    }

  }


  log_post <- t(t(log_lik) + log(prop))

  return(get_z_and_point_lik(log_post))
}





get_z_and_point_lik <- function(log_post){
  K <- ncol(log_post)
  log_point_lik <- matrixStats::rowLogSumExps(log_post)
  post <- exp(log_post - log_point_lik)
  z <- apply(post, 1, \(post_probs_i) sample(x = K, size = 1, prob = post_probs_i))

  return(list("z" = z,
              "point_lik" = exp(log_point_lik)))
}

waic_point_lik <- function(point_lik){
  R <- nrow(point_lik)
  n <- ncol(point_lik)

  llpd <- sum(log(colMeans(point_lik)))
  p_waic2 <- sum(apply(log(point_lik), 2, var))

  waic <- -2 * llpd + 2 * p_waic2
  return(waic)
}


wbic_point_lik <- function(point_lik){
  R <- nrow(point_lik)
  n <- ncol(point_lik)

  log_fxbeta <- rowSums(log(point_lik) / log(n))

  wbic <- - sum(rowSums(log(point_lik)) * exp(log_fxbeta)) / exp(matrixStats::logSumExp(log_fxbeta))
  if(is.nan(wbic)){
    wbic <- exp(matrixStats::logSumExp(log(-rowSums(log(point_lik))) + log_fxbeta) - matrixStats::logSumExp(log_fxbeta))
  }

  return(wbic)
}



update_z_marginal_gk <- function(X, prop, mu, L, psi, g, kappa, monte_carlo = FALSE, B = 1e3, psi_common = FALSE){
  n <- nrow(X)
  p <- ncol(X)
  K <- length(prop)
  q <- dim(L)[2]

  log_lik <- array(dim = c(n, K))

  if(monte_carlo){

    Y <- array(dim = c(B, q, K))
    for(k in 1:K){
      for(j in 1:q){
        z_mc_sample <- rnorm(B)
        Y[, j, k] <- (1 + 0.8 * tanh(0.5 * g[j, k] * z_mc_sample)) * z_mc_sample * (1 + z_mc_sample^2)^kappa[j, k]
      }
    }


    if(psi_common){
      for(k in 1:K){
        for(i in 1:n){
          log_lik[i, k] <- matrixStats::logSumExp(colSums(dnorm(x = X[i, ],
                                                                mean = mu[, k] + L[, , k] %*% t(Y[, , k]),
                                                                sd = sqrt(psi),
                                                                log = TRUE)))
        }
      }
    }else{
      for(k in 1:K){
        for(i in 1:n){
          log_lik[i, k] <- matrixStats::logSumExp(colSums(dnorm(x = X[i, ],
                                                                mean = mu[, k] + L[, , k] %*% t(Y[, , k]),
                                                                sd = sqrt(psi[, k]),
                                                                log = TRUE)))
        }
      }
    }

    log_lik <- log_lik - log(B)

  }else{

    for(k in 1:K){
      fx <- fx_gk_cubature(x = X,
                           mu = mu[, k],
                           L = matrix(L[, , k], nrow = p, ncol = q),
                           psi = psi[, k],
                           g = g[, k],
                           kappa = kappa[, k])
      log_lik[, k] <- log(ifelse((fx <= 0) | (is.nan(fx)), yes = .Machine$double.eps, no = fx))
    }

  }

  log_post <- t(t(log_lik) + log(prop))

  return(get_z_and_point_lik(log_post))
}
