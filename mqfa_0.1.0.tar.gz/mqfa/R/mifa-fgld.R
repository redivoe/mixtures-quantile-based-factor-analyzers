diag1 <- function(x){
  if(length(x) == 1){
    x
  }else{
    diag(x)
  }
}

mifa_fgld <- function(X,
                      K,
                      q,
                      R = 2000,
                      burn_in = 2000,
                      params_init = NULL,
                      z_update = c("fgld_marginal", "fgld_conditional", "normal_marginal"),
                      B = 200,
                      out_mcmc = TRUE,
                      quiet = FALSE){

  n <- nrow(X)
  p <- ncol(X)

  z_update <- match.arg(z_update)
  update_z_fun <- switch(z_update,
                           "fgld_marginal" = update_z_marginal_fgld,
                           "fgld_conditional" = update_z_conditional_fgld,
                           "normal_marginal" = update_z_marginal_mfa)
  update_z_fun_args <- switch(z_update,
                              "fgld_marginal" = c("X", "prop", "mu", "L", "psi", "theta", "B"),
                              "fgld_conditional" = c("X", "prop", "mu", "L", "psi", "Y", "theta"),
                              "normal_marginal" = c("X", "prop", "mu", "L", "psi"))

  # hyperparameter values
  a0_psi <- 0.5
  b0_psi <- 0.5
  a0_omega <- 0.5
  b0_omega <- 0.5
  alpha0_p <- rep(10, K)
  mu0 <- rep(0, p)
  sigma0 <- rep(1, p)
  Sigma0 <- diag(sigma0)
  Sigma0_inv <- diag(1/sigma0)

  # initial values
  if(missing(params_init)){
    params_init <- mifa_random_init(n = n, p = p, q = q, K = K)
  }

  psi <- params_init$psi
  L <- params_init$L
  mu <- params_init$mu
  prop <- params_init$prop
  z <- params_init$z
  theta <- params_init$theta
  nk <- sapply(1:K, \(k) sum(z == k))
  
  if(is.null(params_init$omega)){
    omega <- rep(1, q)
  }else{
    omega <- params_init$omega
  }

  if(is.null(params_init$Y)){
    U <- matrix(runif(n * q), n, q)
    Y <- array(dim = c(n, q))
    for(k in 1:K){
      idx_k <- which(z == k)
      if(length(idx_k) > 0){
        Y[idx_k, ] <- sapply(1:q, \(j) qfgld_origin(U[idx_k, j], theta[, j, k]))
      }
    }
  }else{
    Y <- params_init$Y
  }
  
  if(is.null(params_init$U)){
    U <- matrix(nrow = n, ncol = q)
    for(k in 1:K){
      idx_k <- which(z == k)
      if(length(idx_k) > 0){
        U[idx_k, ] <- sapply(1:q, \(j) pfgld(Y[idx_k, j], theta[, j, k]))
      }
    }    
  }else{
    U <- params_init$U
  }
  
  theta_norm <- array(dim = c(4, q, K))
  for(k in 1:K){
    theta_norm[, , k] <- apply(theta[, , k, drop = FALSE], 2, theta_origin2norm)
  }

  ZU <- qnorm(U)
  Z <- ZU_prop <- U_prop <- Y_prop <- array(dim = c(n, q))

  p_theta <- 2

  update_theta_partial <- function(y, u, eta, theta_norm, S_theta, r){
    eta2theta <- function(eta){
      complete_theta_std(pnorm(eta[1]), exp(eta[2]))
    }
    update_theta(y, u, eta, theta_norm, S_theta, r, p_theta, log_prior_fgld_std, eta2theta)
  }

  get_sdy <- function(theta, Y){
    apply(Y, 2, sd)
  }

  eta <- theta_norm[c(3, 4), , , drop = FALSE]
  S_theta <- array(diag(rep(1, p_theta)), dim = c(p_theta, p_theta, q, K))
  S_u <- array(diag(rep(1, q)), dim = c(q, q, n))

  point_lik <- array(dim = c(R, n))

  if(out_mcmc){
    out <- list(
      L = array(dim = c(R, p * q * K)),
      theta = array(dim = c(R,  4 * q * K)),
      psi = array(dim = c(R, p * K)),
      omega = array(dim = c(R, q)),
      mu = array(dim = c(R, p * K)),
      prop = array(dim = c(R, K)),
      z = array(dim = c(R, n)),
      Y = array(dim = c(R, n * q))
    )

  }else{
    out <- list(
      L = array(dim = c(p, q, K, R)),
      theta = array(dim = c(4, q, K, R)),
      psi = array(dim = c(p, K, R)),
      omega = array(dim = c(q, R)),
      mu = array(dim = c(p, K, R)),
      prop = array(dim = c(K, R)),
      z = array(dim = c(n, R)),
    )
  }

  if(!quiet){
    prog_bar <- progress::progress_bar$new(total = R + burn_in,
                                           format = "[:bar] :percent eta: :eta")
  }


  for (r in 1:(burn_in + R)) {

    b_omega <- rep(0, q)

    for(k in 1:K){
      idx_k <- which(z == k)

      if(length(idx_k) == 0){
        # warning(paste0("Component ", k, " is empty.\t"))

        mu[, k] <- mvnfast::rmvn(n = 1, mu = mu0, sigma = Sigma0)
        for(l in 1:p){
          L[l, , k] <- mvnfast::rmvn(n = 1, mu = rep(0, q), sigma = diag1(omega))
          psi[l, k] <- MCMCpack::rinvgamma(n = 1,
                                           shape = a0_psi,
                                           scale = b0_psi)
        }
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)

      }else{

        for(j in 1:q){
          out_theta_update <- update_theta_partial(Y[idx_k, j], U[idx_k, j], eta[, j, k], theta_norm[, j, k], S_theta[, , j, k], r)
          if(out_theta_update$finite_prior){
            S_theta[, , j, k] <- out_theta_update$S_theta
            if(out_theta_update$new){
              eta[, j, k] <- out_theta_update$eta
              theta_norm[, j, k] <- out_theta_update$theta_norm
              theta[, j, k] <- out_theta_update$theta
              U[idx_k, j] <- out_theta_update$u
            }
          }
        }

        # Y
        Z[idx_k, ] <- matrix(rnorm(nk[k] * q), nk[k], q)
        for(i in idx_k){
          ZU_prop[i, ] <- ZU[i, ] + c(S_u[, , i] %*% Z[i, ])
          U_prop[i, ] <- pnorm(ZU_prop[i, ])
        }
        Y_prop[idx_k, ] <- sapply(1:q, \(j) qfgld_origin(U_prop[idx_k, j], theta[, j, k]))

        A <- t(L[, , k]) %*% diag(1 / psi[, k]) %*% L[, , k]
        b <- sweep(X[idx_k, , drop = FALSE], 2, mu[, k]) %*% diag(1 / psi[, k]) %*% L[, , k]

        for(i in 1:length(idx_k)){
          lp_u_prop <- log_post_u(y = Y_prop[idx_k[i], ], A = A, b = b[i, ]) + sum(dnorm(ZU_prop[idx_k[i], ], log = TRUE))

          if(!is.nan(lp_u_prop)){
            lp_u <- log_post_u(y = Y[idx_k[i], ], A = A, b = b[i, ]) + sum(dnorm(ZU[idx_k[i], ], log = TRUE))
            alpha <- min(1, exp(lp_u_prop - lp_u))
            if(runif(1) < alpha){
              Y[idx_k[i], ] <- Y_prop[idx_k[i], ]
              U[idx_k[i], ] <- U_prop[idx_k[i], ]
              ZU[idx_k[i], ] <- ZU_prop[idx_k[i], ]
            }
            S_u[, , idx_k[i]] <- ramcmc::adapt_S(S_u[, , idx_k[i]], Z[idx_k[i], ], alpha, r)
          }
        }

        # mu
        # Smuk <- solve(nk[k] * diag(1 / psi[, k]) + Sigma0_inv)
        Smuk <- diag(1 / (nk[k] / psi[, k] + 1/sigma0))
        mu[, k] <- mvnfast::rmvn(n = 1,
                                 mu = Smuk %*% (diag(1/psi[, k]) %*% colSums(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k])) + Sigma0_inv %*% mu0),
                                 sigma = Smuk)

        # Lambda
        crossprod_Yk <- crossprod(Y[idx_k, , drop = FALSE])
        for(l in 1:p){
          Slk <- solve(diag1(1 / omega) + crossprod_Yk / psi[l, k])
          mlk <- Slk %*% t(Y[idx_k, , drop = FALSE]) %*% (X[idx_k, l] - mu[l, k]) / psi[l, k]
          L[l, , k] <- mvnfast::rmvn(n = 1, mu = mlk, sigma = Slk)
        }

        b_psi <- colSums(sweep(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k]), 2, mu[, k]) ^ 2)
        for (l in 1:p) {
          psi[l, k] <- MCMCpack::rinvgamma(n = 1,
                                           shape = a0_psi + nk[k] / 2,
                                           scale = b0_psi + b_psi[l] / 2)
        }
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)
      }
    }

    for(j in 1:q){
      omega[j] <- MCMCpack::rinvgamma(n = 1,
                                      shape = a0_omega + K * p / 2,
                                      scale = b0_omega + b_omega[j] / 2)
    }

    if(K > 1){

      out_z_update <- do.call(what = update_z_fun, args = mget(update_z_fun_args))
      z <- out_z_update$z
      nk <- sapply(1:K, \(k) sum(z == k))
      prop <- c(MCMCpack::rdirichlet(n = 1, alpha = alpha0_p + nk))
    }

    if(r > burn_in){
      if(K > 1){
        point_lik[r - burn_in, ] <- out_z_update$point_lik
      }

      if(out_mcmc){
        out$L[r - burn_in, ] <- c(L)
        out$psi[r - burn_in, ] <- psi
        out$omega[r - burn_in, ] <- omega
        out$mu[r - burn_in, ] <- c(mu)
        out$prop[r - burn_in, ] <- prop
        out$z[r - burn_in, ] <- z
        out$theta[r - burn_in, ] <- c(theta)
        out$Y[r - burn_in, ] <- c(Y)
      }else{
        out$L[, , , r - burn_in] <- L
        out$psi[, r - burn_in] <- psi
        out$omega[, r - burn_in] <- omega
        out$mu[, , r - burn_in] <- mu
        out$prop[, r - burn_in] <- prop
        out$z[, r - burn_in] <- z
        out$theta[, , r - burn_in] <- theta
      }
    }

    if (!quiet) {
      prog_bar$tick()
    }

  }

  z_map <- numeric(n)
  for(i in 1:n){
    z_map[i] <- which.max(sapply(1:K, \(k) sum(out$z[,i] == k)))
  }
  out$z_map <- z_map
  out$waic <- waic_point_lik(point_lik)

  return(out)

}

# mifa_fgld_select <- function(X, K_seq, q_seq, R, burn_in, parallel = TRUE, seed = 123){
#   grid <- expand.grid("K" = K_seq, "q" = q_seq)
#   if(parallel){
#     out <- furrr::future_map(array_branch(grid, 1),
#                              \(x) mifa_fgld(X, K = x["K"], q = x["q"], R = R, burn_in = burn_in),
#                              .options = furrr_options(seed = seed))
#   }else{
#     out <- purrr::map(array_branch(grid, 1),
#                       \(x) mifa_fgld(X, K = x["K"], q = x["q"], R = R, burn_in = burn_in))
#   }
#   grid$waic <- purrr::map_dbl(out, "waic")
#   best_idx <- which.min(grid$waic)
#   
#   grid_plot <- grid |>
#     ggplot2::ggplot(ggplot2::aes(x = K, y = waic, col = factor(q)))+
#     ggplot2::geom_line()+
#     ggplot2::labs(col = "q")
#   
#   return(list(
#     "out" = out[[best_idx]],
#     "K" = grid$K[best_idx],
#     "q" = grid$q[best_idx],
#     "grid" = grid,
#     "grid_plot" = grid_plot
#   ))
# }

