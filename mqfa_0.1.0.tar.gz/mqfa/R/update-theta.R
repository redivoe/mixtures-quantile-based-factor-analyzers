
update_theta <- function(y, u, eta, theta_norm, S_theta, r, p_theta, log_prior, eta2theta){
  lp <- log_likelihood_fgld_unbounded_u(u, theta_norm, eps = 1e-10) +
    log_prior(eta)

  z_theta <- rnorm(p_theta)
  eta_prop <- eta + c(S_theta %*% z_theta)
  lprior_prop <- log_prior(eta_prop)

  out <- list()
  out$new <- FALSE
  out$finite_prior <- FALSE

  if (lprior_prop > -Inf) {
    out$finite_prior <- TRUE
    theta_prop <- eta2theta(eta_prop)
    theta_norm_prop <- theta_origin2norm(theta_prop)

    u_prop <- pfgld(y, theta_prop)
    lp_prop <- lprior_prop + log_likelihood_fgld_unbounded_u(u_prop, theta_norm_prop, eps = 1e-10)
    alpha <- min(1, exp(lp_prop - lp))

    if (runif(1) < alpha) {
      out$new <- TRUE
      out$eta <- eta_prop
      out$theta_norm <- theta_norm_prop
      out$theta <- theta_prop
      out$u <- u_prop
    }
    out$S_theta <- ramcmc::adapt_S(S_theta, z_theta, alpha, r)
  }

  return(out)
}




