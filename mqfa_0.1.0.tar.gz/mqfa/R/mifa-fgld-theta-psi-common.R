
mifa_fgld_theta_psi_common <- function(X,
                                   K,
                                   q,
                                   R = 10000,
                                   burn_in = 0,
                                   params_init = NULL,
                                   out_mcmc = TRUE,
                                   quiet = FALSE) {


  n <- nrow(X)
  p <- ncol(X)

  # hyperparameter values
  a0_psi <- 0.5
  b0_psi <- 0.5
  a0_omega <- 0.5
  b0_omega <- 0.5
  alpha_p <- rep(1, K)
  mu0 <- rep(0, p)
  Sigma0 <- diag(rep(1, p))

  # initial values
  if(missing(params_init)){
    psi <- MCMCpack::rinvgamma(n = p, shape = 5, scale = 0.5)
    omega <- MCMCpack::rinvgamma(n = q, shape = 5, scale = 0.5)
    L <- array(rnorm(p * q * K), dim = c(p, q, K))
    mu <- array(rnorm(p * K, sd = 100), dim = c(p, K))
    prop <- MCMCpack::rdirichlet(n = 1,
                                 alpha = rep(p * q * K, K))
    z <- sample(K, size = n, prob = prop, replace = TRUE)
    nk <- sapply(1:K, \(k) sum(z == k))

    U <- matrix(runif(n * q), n, q)
    theta <- rtheta_std(q)
    theta_norm <- apply(theta, 2, theta_origin2norm)
    Y <- sapply(1:q, \(j) qfgld_origin(U[, j], theta[, j]))
  }else{
    psi <- params_init$psi
    L <- params_init$L
    omega <- rep(1, q)
    mu <- params_init$mu
    prop <- params_init$prop
    Y <- params_init$Y
    z <- params_init$z
    nk <- sapply(1:K, \(k) sum(z == k))
    theta <- params_init$theta
    theta_norm <- apply(theta, 2, theta_origin2norm)
    U <- sapply(1:q, \(j) pfgld(Y[, j], theta[, j]))
    # U <- matrix(runif(n * q), n, q)
    # Y <- sapply(1:q, \(j) qfgld_origin(U[, j], c(rtheta_std(1))))
  }

  ZU <- qnorm(U)
  Z <- ZU_prop <- U_prop <- Y_prop <- array(dim = c(n, q))

  p_theta <- 2

  update_theta_partial <- function(y, u, eta, theta_norm, S_theta, r){
    eta2theta <- function(eta){
      complete_theta_std(pnorm(eta[1]), exp(eta[2]))
    }
    update_theta(y, u, eta, theta_norm, S_theta, r, p_theta, log_prior_fgld_std, eta2theta)
  }


  get_sdy <- function(theta, Y){
    apply(Y, 2, sd)
  }

  eta <- theta_norm[c(3, 4), , drop = FALSE]
  S_theta <- array(diag(rep(1, p_theta)), dim = c(p_theta, p_theta, q))
  S_u <- array(diag(rep(1, q)), dim = c(q, q, n))

  if(out_mcmc){
    out <- list(
      L = array(dim = c(R, p * q * K)),
      theta = array(dim = c(R, 4*q)),
      psi = array(dim = c(R, p)),
      omega = array(dim = c(R, q)),
      mu = array(dim = c(R, p * K)),
      prop = array(dim = c(R, K)),
      z = array(dim = c(R, n)),
      Y = array(dim = c(R, n * q))
    )

  }else{
    out <- list(
      L = array(dim = c(p, q, K, R)),
      theta = array(dim = c(4, q, R)),
      psi = array(dim = c(p, R)),
      omega = array(dim = c(q, R)),
      mu = array(dim = c(p, K, R)),
      prop = array(dim = c(K, R)),
      z = array(dim = c(n, R)))
  }

  if(!quiet){
    prog_bar <- progress::progress_bar$new(total = R + burn_in,
                                           format = "[:bar] :percent eta: :eta")
  }


  for (r in 1:(burn_in + R)) {

    for(j in 1:q){
      out_theta_update <- update_theta_partial(Y[, j], U[, j], eta[, j], theta_norm[, j], S_theta[, , j], r)
      if(out_theta_update$finite_prior){
        S_theta[, , j] <- out_theta_update$S_theta
        if(out_theta_update$new){
          eta[, j] <- out_theta_update$eta
          theta_norm[, j] <- out_theta_update$theta_norm
          theta[, j] <- out_theta_update$theta
          U[, j] <- out_theta_update$u
        }
      }
    }

    b_psi <- rep(0, p)
    b_omega <- rep(0, q)

    for(k in 1:K){
      idx_k <- which(z == k)

      if(length(idx_k) == 0){
        warning(paste0("Component ", k, " is empty.\t"))

        mu[, k] <- mvnfast::rmvn(n = 1, mu = mu0, sigma = Sigma0)
        for(l in 1:p){
          L[l, , k] <- mvnfast::rmvn(n = 1, mu = rep(0, q), sigma = diag1(omega))
        }
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)

      }else{

        # Y
        Z[idx_k, ] <- matrix(rnorm(nk[k] * q), nk[k], q)
        for(i in idx_k){
          ZU_prop[i, ] <- ZU[i, ] + c(S_u[, , i] %*% Z[i, ])
          U_prop[i, ] <- pnorm(ZU_prop[i, ])
        }
        Y_prop[idx_k, ] <- sapply(1:q, \(j) qfgld_origin(U_prop[idx_k, j], theta[, j]))

        A <- t(L[, , k]) %*% diag(1 / psi) %*% L[, , k]
        b <- sweep(X[idx_k, , drop = FALSE], 2, mu[, k]) %*% diag(1 / psi) %*% L[, , k]

        for(i in 1:length(idx_k)){
          lp_u_prop <- log_post_u(y = Y_prop[idx_k[i], ], A = A, b = b[i, ]) + sum(dnorm(ZU_prop[idx_k[i], ], log = TRUE))

          if(!is.nan(lp_u_prop)){
            lp_u <- log_post_u(y = Y[idx_k[i], ], A = A, b = b[i, ]) + sum(dnorm(ZU[idx_k[i], ], log = TRUE))
            alpha <- min(1, exp(lp_u_prop - lp_u))
            if(runif(1) < alpha){
              Y[idx_k[i], ] <- Y_prop[idx_k[i], ]
              U[idx_k[i], ] <- U_prop[idx_k[i], ]
              ZU[idx_k[i], ] <- ZU_prop[idx_k[i], ]
            }
            S_u[, , idx_k[i]] <- ramcmc::adapt_S(S_u[, , idx_k[i]], Z[idx_k[i], ], alpha, r)
          }
        }

        # mu
        Smuk <- solve(nk[k] * diag(1 / psi) + solve(Sigma0))
        mu[, k] <- mvnfast::rmvn(n = 1,
                                 mu = Smuk %*% (diag(1/psi) %*% colSums(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k])) + solve(Sigma0) %*% mu0),
                                 sigma = Smuk)

        # Lambda
        for(l in 1:p){
          Yl <- Y[idx_k, , drop = FALSE]
          Slk <- solve(diag1(1 / omega) + crossprod(Yl) / psi[l])
          mlk <- Slk %*% t(Yl) %*% (X[idx_k, l] - mu[l, k]) / psi[l]
          L[l, , k] <- mvnfast::rmvn(n = 1, mu = mlk, sigma = Slk)
        }

        b_psi <- b_psi + colSums(sweep(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k]), 2, mu[, k]) ^ 2)
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)
      }
    }

    for (l in 1:p) {
      psi[l] <- MCMCpack::rinvgamma(n = 1,
                                    shape = a0_psi + n / 2,
                                    scale = b0_psi + 0.5 * b_psi[l])
    }
    for(j in 1:q){
      omega[j] <- MCMCpack::rinvgamma(n = 1,
                                      shape = a0_omega + K * p / 2,
                                      scale = b0_omega + b_omega[j])
    }

    if(K > 1){
      z <- update_z_conditional(X, prop, mu, L, psi, Y)
      nk <- sapply(1:K, \(k) sum(z == k))
      prop <- MCMCpack::rdirichlet(n = 1, alpha = alpha_p + nk)
    }

    if(r > burn_in){

      if(out_mcmc){
        out$L[r - burn_in, ] <- c(L)
        out$psi[r - burn_in, ] <- psi
        out$omega[r - burn_in, ] <- omega
        out$mu[r - burn_in, ] <- c(mu)
        out$prop[r - burn_in, ] <- prop
        out$z[r - burn_in, ] <- z
        out$theta[r - burn_in, ] <- c(theta)
        out$Y[r - burn_in, ] <- c(Y)
      }else{
        out$L[, , , r - burn_in] <- L
        out$psi[, r - burn_in] <- psi
        out$omega[, r - burn_in] <- omega
        out$mu[, , r - burn_in] <- mu
        out$prop[, r - burn_in] <- prop
        out$z[, r - burn_in] <- z
        out$theta[, , r - burn_in] <- theta
      }
    }

    if (!quiet) {
      prog_bar$tick()
    }

  }

  z_map <- numeric(n)
  for(i in 1:n){
    z_map[i] <- which.max(sapply(1:K, \(k) sum(out$z[,i] == k)))
  }
  out$z_map <- z_map

  return(out)

}

