
mfa_px <- function(X,
                   K,
                   q,
                   R = 10000,
                   burn_in = 0,
                   params = NULL,
                   out_mcmc = TRUE,
                   z_update_distr = c("marginal", "conditional"),
                   quiet = FALSE){

  n <- nrow(X)
  p <- ncol(X)

  # distribution for updating z
  z_update_distr <- match.arg(z_update_distr)

  # hyperparameter values
  a0_psi <- 0.5
  b0_psi <- 0.5
  a0_omega <- 0.5
  b0_omega <- 0.5
  alpha_p <- rep(1, K)
  mu0 <- rep(0, p)
  Sigma0 <- diag(rep(1, p))
  a0_phi <- rep(0.5, q)
  b0_phi <- rep(0.5, q)

  # number of free parameters for each row of Lambda
  pl <- c(1:q, rep(q, p - q))

  # initial values
  psi <- MCMCpack::rinvgamma(n = p, shape = a0_psi, scale = b0_psi)
  omega <- MCMCpack::rinvgamma(n = q, shape = a0_omega, scale = b0_omega)
  phi <- MCMCpack::rinvgamma(n = q, shape = a0_phi, scale = b0_phi)
  L <- array(rnorm(p * q * K, sd = 2), dim = c(p, q, K))
  for(k in 1:K){
    L[, , k][upper.tri(L[, , k])] <- 0
    diag(L[, , k]) <- rexp(q)
  }
  mu <- array(rnorm(p * K, sd = 2), dim = c(p, K))
  prop <- MCMCpack::rdirichlet(n = 1,
                               # alpha = rep((2 * p + p * q - q * (q - 1) / 2)/2, K))
                               alpha = rep(p * q * K, K))
  z <- sample(K, size = n, prob = prop, replace = TRUE)
  nk <- sapply(1:K, \(k) sum(z == k))

  # psi <- params$psi
  # L <- params$L
  # mu <- params$mu
  # prop <- params$prop
  # Y <- params$Y
  # z <- params$z
  # nk <- sapply(1:K, \(k) sum(z == k))

  Y <- array(dim = c(n, q)) # empty

  if(out_mcmc){
    out <- list(
      L = array(dim = c(R, p * q * K)),
      psi = array(dim = c(R, p)),
      omega = array(dim = c(R, q)),
      mu = array(dim = c(R, p * K)),
      prop = array(dim = c(R, K)),
      z = array(dim = c(R, n))
    )
  }else{
    out <- list(
      L = array(dim = c(p, q, K, R)),
      psi = array(dim = c(p, R)),
      omega = array(dim = c(q, R)),
      mu = array(dim = c(p, K, R)),
      prop = array(dim = c(K, R)),
      z = array(dim = c(R, n))
    )
  }

  if(!quiet){
    prog_bar <- progress::progress_bar$new(total = R + burn_in,
                                           format = "[:bar] :percent eta: :eta")
  }


  for (r in 1:(burn_in + R)) {
    b_psi <- rep(0, p)
    b_omega <- rep(0, q)

    for(k in 1:K){
      idx_k <- which(z == k)

      if(length(idx_k) == 0){
        warning(paste0("Component ", k, " is empty.\t"))

        mu[, k] <- mvnfast::rmvn(n = 1, mu = mu0, sigma = Sigma0)
        for(l in 1:p){
          L[l, 1:pl[l], k] <- mvnfast::rmvn(n = 1, mu = rep(0, pl[l]), sigma = diag1(omega[1:pl[l]]))
        }
        b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)

      }

      # Y
      Syk <- solve(diag(1 / phi) + t(L[, , k]) %*% diag(1 / psi) %*% L[, , k])
      myk <- sweep(X[idx_k, , drop = FALSE], 2, mu[, k]) %*% diag(1 / psi) %*% L[, , k] %*% Syk
      Y[idx_k, ] <- myk + mvnfast::rmvn(n = nk[k], mu = rep(0, q), sigma = Syk)

      # mu
      Smuk <- solve(nk[k] * diag(1 / psi) + solve(Sigma0))
      mu[, k] <- mvnfast::rmvn(n = 1,
                               mu = Smuk %*% (diag(1/psi) %*% colSums(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k])) + solve(Sigma0) %*% mu0),
                               sigma = Smuk)

      # Lambda
      for(l in 1:p){
        Yl <- Y[idx_k, 1:pl[l], drop = FALSE]
        Slk <- solve(diag1(1 / omega[1:pl[l]]) + crossprod(Yl) / psi[l])
        mlk <- Slk %*% t(Yl) %*% (X[idx_k, l] - mu[l, k]) / psi[l]
        L[l, 1:pl[l], k] <- mvnfast::rmvn(n = 1, mu = mlk, sigma = Slk)
      }

      b_psi <- b_psi + colSums(sweep(X[idx_k, , drop = FALSE] - Y[idx_k, , drop = FALSE] %*% t(L[, , k]), 2, mu[, k]) ^ 2)
      b_omega <- b_omega + colSums(L[, , k, drop = FALSE] ^ 2)
    }


    for (l in 1:p) {
      psi[l] <- MCMCpack::rinvgamma(n = 1,
                                    shape = a0_psi + n / 2,
                                    scale = b0_psi + 0.5 * b_psi[l])
    }

    b_phi <- 0.5 * colSums(Y ^ 2)

    for(j in 1:q){
      omega[j] <- MCMCpack::rinvgamma(n = 1,
                                      shape = a0_omega + K * p / 2,
                                      scale = b0_omega + b_omega[j])
      phi[j] <- MCMCpack::rinvgamma(1,
                                    shape = a0_phi + n / 2,
                                    scale = b0_phi + b_phi[j])
    }

    if(K > 1){
      z <- switch(z_update_distr,
                  "marginal" = update_z_marginal(X, prop, mu, L, psi),
                  "conditional" = update_z_conditional(X, prop, mu, L, psi, Y))
      nk <- sapply(1:K, \(k) sum(z == k))
      prop <- MCMCpack::rdirichlet(n = 1, alpha = alpha_p + nk)
    }

    if(r > burn_in){

      L_id <- L
      for(k in 1:K){
        neg_diag_L <- diag(L[, , k]) < 0
        L_id[, neg_diag_L, k] <- -L_id[, neg_diag_L, k]
        L_id[, , k] <- L_id[, , k] %*% diag(sqrt(phi))
      }

      if(out_mcmc){
        out$L[r - burn_in, ] <- c(L_id)
        out$psi[r - burn_in, ] <- psi
        out$omega[r - burn_in, ] <- omega
        out$mu[r - burn_in, ] <- c(mu)
        out$prop[r - burn_in, ] <- prop
        out$z[r - burn_in, ] <- z
      }else{
        out$L[, , , r - burn_in] <- L_id
        out$psi[, r - burn_in] <- psi
        out$omega[, r - burn_in] <- omega
        out$mu[, , r - burn_in] <- mu
        out$prop[, r - burn_in] <- prop
        out$z[r - burn_in, ] <- z
      }
    }

    if (!quiet) {
      prog_bar$tick()
    }

  }

  z_map <- numeric(n)
  for(i in 1:n){
    z_map[i] <- which.max(sapply(1:K, \(k) sum(out$z[, i] == k)))
  }
  out$z_map <- z_map

  return(out)

}



