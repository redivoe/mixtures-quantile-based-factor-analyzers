mcmc_stan <- function(fit, var){
  fit$draws(var) |>
    unclass() |>
    drop()
}

mcmc_rstan <- function(fit, var){
  extract(fit, var) |>
    unclass() |>
    drop()
}

mode <- function(x){
  as.numeric(names(sort(-table(x)))[1])
}

get_z_map <- function(z_mcmc){
  apply(z_mcmc, 2, mode)
}

# get_z_mifa_fgld_rstan <- function(stanfit, X){
#   out_samples <- rstan::extract(stanfit, permuted = TRUE)
#
#   R <- nrow(out_samples$prop)
#   K <- ncol(out_samples$prop)
#   q <- dim(out_samples$alpha)[3]
#   n <- nrow(X)
#
#   out_samples$L <- purrr::array_branch(out_samples$Lambda, 1) |>
#     purrr::map(aperm, perm = c(2, 3, 1))
#   out_samples$theta <- vector(mode = "list", length = R)
#   for(r in 1:R){
#     out_samples$theta[[r]] <- array(dim = c(4, q, K))
#     for(k in 1:K){
#       for(j in 1:q){
#         out_samples$theta[[r]][, j, k] <- c(out_samples$alpha[r, k, j],
#                                             out_samples$beta[r, k, j],
#                                             out_samples$delta[r, k, j],
#                                             out_samples$kappa[r, k, j])
#       }
#     }
#   }
#
#   z <- array(dim = c(R, n))
#   for(r in 1:R){
#     z[r, ] <- update_z_marginal_fgld(X = X,
#                                      prop = out_samples$prop[r,],
#                                      mu = t(out_samples$mu[r, , ]),
#                                      L =  out_samples$L[[r]],
#                                      psi = t(out_samples$psi[r, , ]),
#                                      theta = out_samples$theta[[r]])$z
#   }
#   return(z)
# }


offline_z_mifa_cmdstanr <- function(fit, X, distr = "fgld", monte_carlo = FALSE, B = 1000){

  samples <- posterior::as_draws_rvars(fit$draws()) |>
    purrr::map(posterior::draws_of)

  R <- nrow(samples$prop)
  K <- ncol(samples$prop)
  if(distr == "fgld"){
    q <- dim(samples$delta)[3]
  }else if(distr == "gk"){
    q <- dim(samples$g)[3]
  }
  n <- nrow(X)

  samples$L <- purrr::array_branch(samples$Lambda, 1) |>
    purrr::map(aperm, perm = c(2, 3, 1))
  samples$mu <- aperm(samples$mu, c(1, 3, 2))
  samples$psi <- aperm(samples$psi, c(1, 3, 2))

  z <- array(dim = c(R, n))
  point_lik <- array(dim = c(R, n))

  if(distr == "gk"){
    samples$g <- aperm(samples$g, c(1, 3, 2))
    samples$kappa <- aperm(samples$kappa, c(1, 3, 2))

    for(r in 1:R){
      out_z_update <- update_z_marginal_gk(X = X,
                                           prop = samples$prop[r, ],
                                           mu = samples$mu[r , , ],
                                           L =  samples$L[[r]],
                                           psi = samples$psi[r, , ],
                                           g = matrix(samples$g[r, , ], nrow = q, ncol = K),
                                           kappa = matrix(samples$kappa[r, ,], nrow = q, ncol = K),
                                           monte_carlo = monte_carlo,
                                           B = B)
      z[r, ] <- out_z_update$z
      point_lik[r, ] <- out_z_update$point_lik

    }

  }else if(distr == "fgld"){

    samples$theta <- vector(mode = "list", length = R)
    for(r in 1:R){

      samples$theta[[r]] <- array(dim = c(4, q, K))
      for(k in 1:K){
        for(j in 1:q){
          samples$theta[[r]][, j, k] <- complete_theta_std(delta = samples$delta[r, k, j],
                                                           kappa = samples$kappa[r, k, j])
        }
      }

      out_z_update <- update_z_marginal_fgld(X = X,
                                             prop = samples$prop[r, ],
                                             mu = samples$mu[r , , ],
                                             L =  samples$L[[r]],
                                             psi = samples$psi[r, , ],
                                             theta = samples$theta[[r]],
                                             monte_carlo = monte_carlo,
                                             B = B)
      z[r, ] <- out_z_update$z
      point_lik[r, ] <- out_z_update$point_lik

    }
  }


  z_map <- numeric(n)
  for(i in 1:n){
    z_map[i] <- which.max(tabulate(bin = z[, i], nbins = K))
  }

  return(list(
    "z" = z,
    "z_map" = z_map,
    "waic" = waic_point_lik(point_lik),
    "wbic" = wbic_point_lik(point_lik)
  ))
}
